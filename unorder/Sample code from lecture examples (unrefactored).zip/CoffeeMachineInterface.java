public interface CoffeeMachineInterface {
    public void addCoffee(String coffeeType);
    public void brewCoffee();
    public void brewExpressoCoffee();
    
}
