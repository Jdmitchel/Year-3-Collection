public interface ExpressoCoffeeMachineInterface extends CoffeeMachineInterface{
    
}
