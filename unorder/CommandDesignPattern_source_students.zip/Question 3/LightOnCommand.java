
import java.util.*;

/**
 * 
 */
public class LightOnCommand implements Command {

    /**
     * Default constructor
     */
    public LightOnCommand() {
    }

    /**
     * 
     */
    private Light light;


    /**
     * @param Light
     */
    public void LightOnCommand(void Light) {
        // TODO implement here
    }

    /**
     * 
     */
    public void execute() {
        // TODO implement here
    }

    /**
     * 
     */
    public void execute() {
        // TODO implement here
    }

}