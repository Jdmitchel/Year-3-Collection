/* 	Name: Varsha Roopchand
	ID: 81603943
	Assignment 3 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cmath>

using namespace std;

//Writes a function that identifies a if an integer is a prime number.
bool isPrime (int n){
	if(n < 2)
		return false;
	
	for(int i= 2; i <= sqrt(n); i++){
		if((n%i)==0)
		return false;
	}
	return true;
}

// Writes a function that identifies if an integer n is the product of 2 prime numbers and return one prime multiple.
int product2Primes (int n){
	for(int i = 2; i<= n/2; i++){
		if((n%i)==0){
			if( isPrime(i) && isPrime(n/i)){
				if (i != n/i)
					return i;
			}
		}
	}
	return -1;
}

// Writes a function that identifies if an integer n is an almost square number and returns the integer square root of the integer.
int isAlmostSquare (int n) {
	int x,y;
	x =sqrt(n);
	y = sqrt(n) +1;
	
	if (n==(x*y))
		return x;
	else 
		return -1;
}

// Writes a function that finds and return the sum of the digits in an integer n.
int sumDigits(int n) {
    int sum = 0;
    while (n > 0) {
        sum += n % 10;
        n = n / 10;
    }
    return sum;
}
// Writes a function that identifies if an integer n is a pathak number.
bool isPathak (int n){
	if((n%sumDigits(n))==0)
		return true;
	else
		return false;
}

// Writes a function that identifies if an integer n is a binary number.
bool isBinary(int n) {
    while (n != 0) {
        if (n % 10 > 1)
            return false;
        n = n / 10;
    }
    return true;
}

// Writes a function that identifies if an integer n is a slightly wavy number.
bool isSlightlyWavy(int n) {
    int original_n = n;
    int last_digit = n % 10;
    n = n / 10;
    
    while (n > 0) {
        int current_digit = n % 10;
        
        if (abs(current_digit - last_digit) != 1) {
            return false;
        }

        last_digit = current_digit;
        n = n / 10;
    }

    // Check the first and last digits
    return abs(original_n % 10 - last_digit) == 1;
}

// Writes a function that displays the series of the sum of 1 to an integer x.
void sum(int x) {
	int i, sum;
	sum = 0;
	for (i = 1; i <= x; i++) {
		sum += i;
		cout << i;
		if (i != x) {
			cout << " + ";
		}
	}
	cout << " = " << sum << endl;
}

// Writes a function that identifies if an integer n is a triangular number and returns the series of additions to get the triangular number.
int triangular(int n) {
	int i, sum;
	sum = 0;
	for (i = 1; i <= n; i++) {
		sum += i;
		if (sum == n) {
			return i;
		}
	}
	return -1;
}

int main(){
	ifstream inputFile;
	
	string username, country;
	int i,fav_num, max, min, sum, num_element, pat_max, pat_min;
	int fav_numtt[1000];
	float avg;
	
	// initializing variables
	max =-1;
	min = 11000000;
	sum = 0;
	pat_max = -1;
	pat_min = 1100000;
	num_element = 0;
	
	inputFile.open("InputData.txt"); // opening file
	
	if(!inputFile.is_open()){ //ensuring file is opened
		cout << "Error opening input file. Aborting ...";
		exit(1);
	}
	
	inputFile >> username; // reading information from file
	while(username != "END" && inputFile >> country){
		inputFile >> fav_num;
		
		if(country == "tt"){ // storing the favourite numbers of tt person in an array
			if (num_element < 1000) {
            	fav_numtt[num_element] = fav_num;
            	num_element++;
        	}
		}
		inputFile >> username;
	}
	inputFile.close(); //closing file
	
	for(i= 0; i < num_element; i++){ //transvering array to determine the max, min and average of the numbers stored
		if (fav_numtt[i] > max)
			max = fav_numtt[i];
				
		if(fav_numtt[i] < min)
			min  = fav_numtt[i];
				
		sum += fav_numtt[i];			 
	}
	
	cout << fixed << setprecision(2);
	
	if (i != 0) 
        avg = (sum*1.0) / num_element;
    else
		avg = 0.0;
	
	cout << "There are " << i <<  " numbers for users from Trinidad and Tobago in the file.\n";
	cout << "The smallest number is " << min << "." << endl;
	cout << "The biggest number is " << max << "." << endl;
	cout << "The average of the numbers is " << avg << endl << endl;
		
	// Determining which numbers are almost square
	cout << "The following are the almost-square numbers: " << endl;
	for(i= 0; i < num_element; i++){
		if(isAlmostSquare(fav_numtt[i]) != -1)
			cout << fav_numtt[i] << ":	" << isAlmostSquare (fav_numtt[i]) << " x " << (isAlmostSquare (fav_numtt[i]) + 1) << endl;
	}
	
	cout<<endl;
	// Determining which numbers are Pathak numbers
	cout << "The following are the Pathak numbers: " << endl;
	for(i= 0; i < num_element; i++){
		if(isPathak(fav_numtt[i]) == true)
			cout << fav_numtt[i] << ":	" <<  sumDigits (fav_numtt[i]) << " x " << (fav_numtt[i]/sumDigits (fav_numtt[i])) << endl;
	}	
	
	cout<<endl;
	// Determining which numbers are binary
	cout << "The following are the binary numbers: " << endl;
	for(i= 0; i < num_element; i++){
		if(isBinary(fav_numtt[i]) == true)	
			cout << fav_numtt[i] << endl;
	}
	
	cout<<endl;
	// Determining which numbers are slighlty wavy
	cout << "The following are the slightly-wavy numbers: " << endl;
	for(i= 0; i < num_element; i++){
		if(isSlightlyWavy(fav_numtt[i]) == true)
			cout << fav_numtt[i] << endl;
	}
	
	cout<<endl;
	// Determining which numbers are the product of two prime numbers
	cout << "The following are the numbers which are the product of two prime numbers: " << endl;
	for(i= 0; i < num_element; i++){
		if(product2Primes(fav_numtt[i]) != -1)
			cout << fav_numtt[i] << ":	" <<product2Primes (fav_numtt[i]) << " x " << (fav_numtt[i]/product2Primes (fav_numtt[i])) << endl;
	}
	
	cout<<endl;
	// Determining which numbers are both Pathak and slightly wavy and determines the largest and smallest of the numbers
	cout << "The following Pathak numbers are also slightly-wavy: " << endl;
	for(i= 0; i < num_element; i++){
		if((isPathak(fav_numtt[i]) == true)&&(isSlightlyWavy (fav_numtt[i])==true)){
			cout << fav_numtt[i] << endl;
			
			if(fav_numtt[i] > pat_max)
			pat_max = fav_numtt[i]; 
			
			if(fav_numtt[i] < pat_min)
			pat_min = fav_numtt[i];
		}
	}
	cout<<endl;
	cout << "	--> The biggest one is " << pat_max << endl;
	cout << "	--> The smallest one is " << pat_min<< endl;
	
	cout<<endl;
	// Determining which numbers are triangular numbers
cout << "The following are the triangular numbers: " << endl;
	for (i = 0; i < num_element; i++) { // printing the triangular numbers
		if (triangular(fav_numtt[i]) != -1) {
			sum(triangular(fav_numtt[i]));
		} 
	}	
	
	cout<<endl;
	cout << "End of Program!";
	return 0;
}
/* Variable name and meanings
	username- the name of the person who enter their favourite number from the file, country- the country of the person in file
	i-a counter for loops,fav_num- the favourite number of person, max- maximum value of fav_num, min- the minimun value of fav_num, sum- the sum of values, num_element- the number of elements in the array, pat_max- the largest pathak number that is slightly wavy, pat_min- the smallest pathak number that is slightly wavy
	fav_numtt[1000] - thearray containg the favourite numbers of tt persons and its size
	avg - the average of the values from fav_numtt[1000] */
