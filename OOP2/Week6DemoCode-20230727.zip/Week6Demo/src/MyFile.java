public class MyFile implements MyData{

    private String name;
    public MyFile(String name){
        this.name = name;
    }
    public void print(){
        System.out.println(name);
    }
}