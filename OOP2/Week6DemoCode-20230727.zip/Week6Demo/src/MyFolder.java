public class MyFolder implements MyData{
    private String name;
    private java.util.ArrayList<MyData> contents;
    public MyFolder(String name){
        this.name = name;
        contents = new java.util.ArrayList<MyData>();
    }

    public void addData(MyData newStuff){
        contents.add(newStuff);
    }

    public void print(){
        System.out.println(name.toUpperCase());
        for (MyData data: contents){         
            data.print();

        }
    }
}