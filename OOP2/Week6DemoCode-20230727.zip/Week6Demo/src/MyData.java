public interface MyData{
    public void print();
}