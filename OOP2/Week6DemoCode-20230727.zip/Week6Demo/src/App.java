public class App {
    public static void main(String[] args) throws Exception {
        MyFolder music = new MyFolder("music");
        
        music.addData(new MyFile("Don't worry be happy.mp3"));
        MyFolder songs = new MyFolder("scorpions");
        songs.addData(new MyFile("winds of change.mp3"));
        music.addData(songs);

        music.print();
    }
}
