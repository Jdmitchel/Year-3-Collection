package week10;

import org.junit.jupiter.api.AfterEach; //previously After
import org.junit.jupiter.api.AfterAll; //previously AfterClass
import org.junit.jupiter.api.BeforeEach; //previously Before
import org.junit.jupiter.api.BeforeAll;  //previously BeforeClass in Junit4
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
//import org.junit.jupiter.api.DisplayName;

/**
 *
 * @author phaedramohammed
 */
public class LecturerTest {
    private Lecturer bob;
    /*
   
   
    @Test
    public void testCreateLecturer(){
        String fName = bob.getFirstName();
        String lName = bob.getLastName();
        String posn = bob.getPosition();
        
        assertEquals("Bob", fName);
        assertEquals("Doe", lName);
        assertEquals("Assistant Lecturer", posn);
    }
    */
    
    public LecturerTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
     // This method runs before each test method
    // can renamed to initialiseLecturerObjects
    @BeforeEach
    public void setUp() {
        bob = new Lecturer("Bob", "Doe", "Assistant Lecturer");
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of getFirstName method, of class Lecturer.@DisplayName("😱 emoji name")
     */
    @Test
    
    public void testGetFirstName() {
        System.out.println("getFirstName"); 
        String expResult = "Bob";
        String result = bob.getFirstName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getLastName method, of class Lecturer.
     */
    @Test
    public void testGetLastName() {
        System.out.println("getLastName");
        String expResult = "Doe";
        String result = bob.getLastName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getPosition method, of class Lecturer.
     */
    @Test
    public void testGetPosition() {
        System.out.println("getPosition");
        String expResult = "Assistant Lecturer";
        String result = bob.getPosition();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
       // fail("The test case is a prototype.");
    }

    /**
     * Test of getSalary method, of class Lecturer.
     */
    @Test
    public void testGetSalary() {
        System.out.println("getSalary");
        double expResult = 5000.0;
        double result = bob.getSalary();
        assertEquals(expResult, result, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getID method, of class Lecturer.
     */
    @Test
    public void testGetID() {
        System.out.println("getID"); 
        
        int result = bob.getID();
        Lecturer phil = new Lecturer ("Phillip", "Head", "Lecturer");
       
        int expResult = phil.getID();
        assertEquals(expResult-10, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
}
