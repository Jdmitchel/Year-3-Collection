
package week10;


import org.junit.jupiter.api.AfterEach; //previously After
import org.junit.jupiter.api.AfterAll; //previously AfterClass
import org.junit.jupiter.api.BeforeEach; //previously Before
import org.junit.jupiter.api.BeforeAll;  //previously BeforeClass in Junit4
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author phaedramohammed
 *
 * 
 * There have been changes from JUnit 4 to JUnit5 
 * These are listed here:  https://www.baeldung.com/junit-5
 */
public class DepartmentTest {
    
    private Department dept;
    private Lecturer Halley;
    
    public DepartmentTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    

    @BeforeEach
    public void setUp() {
        dept = new Department();
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of getNumLecturers method, of class Department.
     */
    @Test
    public void testGetNumLecturers() {
        System.out.println("getNumLecturers");
        int expResult = 0;
        int result = dept.getNumLecturers();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
       // fail("The test case is a prototype.");
    }

    /**
     * Test of getLecturers method, of class Department.
     */
    @Test
    public void testGetLecturers() {
        System.out.println("getLecturers");
         Lecturer[] result = dept.getLecturers();
        assertNotNull(result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of addLecturer method, of class Department.
     */
    @Test
    public void testAddLecturer() {
        System.out.println("addLecturer");
        String firstName = "Halley";
        String lastName = "Zu";
        String position = "Senior Lecturer";
        Lecturer result = dept.addLecturer(firstName, lastName, position);
        assertNotNull( result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getLecturer method, of class Department.
     */
    @Test
    public void testGetLecturer() {
        System.out.println("getLecturer");
        int ID = 10;
        Lecturer expResult = Halley;
        Lecturer result = dept.getLecturer(ID);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
}
