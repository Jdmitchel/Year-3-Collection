package week11labB;
// include appropriate imports

import week11labB.domain.Activity;
import week11labB.storage.ActivityExporter;
import week11labB.storage.ActivityImporter;
import week11labB.storage.JSONActivityExporter;
import week11labB.storage.JSONActivityImporter;
import week11labB.storage.XMLActivityExporter;
import week11labB.storage.XMLActivityImporter;

public final class App {
 
    public static void main(String[] args) {
        //Create a few activity objects and store in a collection
        java.util.ArrayList<Activity> exercises = new java.util.ArrayList<Activity>();
        for(int i = 0; i<5; i++){
            exercises.add(new Activity());
        }
        for(Activity a: exercises)
            System.out.println(a.toString());

        //Declare Generic export/import objects
        ActivityExporter activityExporter = new JSONActivityExporter();
        ActivityImporter activityImporter = new JSONActivityImporter();
        
      // JSON export/import invocations
        try{
            for(Activity a: exercises){
                activityExporter.exportActivity(a);
            }

            //get filenames
            for(Activity a: exercises){
                Activity importedActivity= activityImporter.importActivity(a.getFilename());
                System.out.println("From JSON: " + importedActivity.toString());
            }  
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
       
  
        
        //XML export/import invocations
        ActivityExporter activityExporterXML = new XMLActivityExporter();
        ActivityImporter activityImporterXML = new XMLActivityImporter();
        
        try{
            for(Activity a: exercises){
                activityExporterXML.exportActivity(a);
            }

            //get filenames
            for(Activity a: exercises){
                Activity importedActivityXML= activityImporterXML.importActivity(a.getFilename());
                System.out.println("From XML: " + importedActivityXML.toString());
            }  
            
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
       
     
    }
}

