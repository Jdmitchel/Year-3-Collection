package week11labB.storage;

import com.fasterxml.jackson.databind.ObjectMapper;

import week11labB.domain.Activity;

public class JSONActivityImporter implements ActivityImporter {

    @Override
    public Activity importActivity(String filename) throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        Activity a = mapper.readValue(new java.io.File("src/files/"+filename+".json"), Activity.class);
        return a;
    }
    
}
