package week11labB.storage;

import javax.xml.bind.JAXB;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;

import week11labB.domain.Activity;

public class XMLActivityImporter implements ActivityImporter {

    @Override
    public Activity importActivity(String filename) throws Exception {
        java.io.File file = new java.io.File("src/files/"+filename+".xml");
        JAXBContext contextObject = JAXBContext.newInstance(Activity.class);
        Unmarshaller unmarshallerObject = contextObject.createUnmarshaller();
        Activity a = (Activity) unmarshallerObject.unmarshal(file); //Object instance
        return a;
    }
    
}
