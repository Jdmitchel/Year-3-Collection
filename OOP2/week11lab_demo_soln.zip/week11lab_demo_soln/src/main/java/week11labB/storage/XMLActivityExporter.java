package week11labB.storage;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;

import week11labB.domain.Activity;

public class XMLActivityExporter implements ActivityExporter{

    @Override
    public void exportActivity(Activity a) throws Exception {
        JAXBContext contextObject = JAXBContext.newInstance(Activity.class);
        Marshaller marshallerObject = contextObject.createMarshaller();
        marshallerObject.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
        marshallerObject.marshal(a, new java.io.File("src/files/"+a.getFilename()+".xml") );
        
    }
    
}
