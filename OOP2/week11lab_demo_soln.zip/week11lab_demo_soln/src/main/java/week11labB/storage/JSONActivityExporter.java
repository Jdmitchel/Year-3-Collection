package week11labB.storage;

import week11labB.domain.Activity;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JSONActivityExporter implements ActivityExporter{

    @Override
    public void exportActivity(Activity a) throws Exception {
      ObjectMapper mapper = new ObjectMapper(); //needed from the Jackson package to handle serialisation
      mapper.writeValue(new java.io.File("src/files/"+a.getFilename()+".json"), a);
    }
   
}