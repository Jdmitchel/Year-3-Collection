/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question2;

/**
 *
 * @author phaedramohammed
 */
public class AC implements OnOffDevice{
    private boolean on;

    public void switchOn(){
        on = true;
        System.out.println("AC on");
    }

    public void switchOff(){
        on = false;
        System.out.println("AC off");
    }
}
