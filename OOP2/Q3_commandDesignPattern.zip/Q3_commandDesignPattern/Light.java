package question2;

/**
 *
 * @author phaedramohammed
 */
public class Light implements OnOffDevice{
    
    private boolean on;

    public void switchOn(){
        on = true;
        System.out.println("Lights on");
    }

    public void switchOff(){
        on = false;
        System.out.println("Lights off");
    }

}
