import Q5.Animal;
import Q5.Cat;
import Q5.NoisyAnimal;

public class App {
    public static void main(String[] args) throws Exception {
       Animal jeff = new Animal();
       jeff.eat();

       NoisyAnimal garfield = new Cat();
       garfield.makeNoise();
   

       NoisyAnimal clifford = new Q5.Dog();
       clifford.makeNoise();


       Animal spike = new Q5.DeafDog();
       spike.eat();
    }
}
