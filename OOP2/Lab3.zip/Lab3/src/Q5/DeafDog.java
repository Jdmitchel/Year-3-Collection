package Q5;
public class DeafDog extends Animal{
    public void eat(){
        super.eat();
        System.out.println("nom nom nom");
    }
}
