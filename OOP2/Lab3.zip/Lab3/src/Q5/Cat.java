package Q5;
public class Cat extends Animal implements NoisyAnimal{
    public void makeNoise(){
        System.out.println("meow meow");
    }
}
