package Q5;
public class Animal{
    /*public void makeNoise(){
        System.out.println("I am making noise");
    }*/
    public void eat(){
        System.out.println("chomp chomp");
    }
}