package Q5;
public class Dog extends Animal implements NoisyAnimal{
    public void makeNoise(){
        System.out.println("woof woof");
    }
}
