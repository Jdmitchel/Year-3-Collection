package Q5;
public interface NoisyAnimal {
    public void makeNoise();
}
