
import java.util.*;

/**
 * 
 */
public class LightOffCommand implements Command {

    /**
     * Default constructor
     */
    public LightOffCommand() {
    }

    /**
     * 
     */
    private Light light;


    /**
     * 
     */
    public void LightOffCommand(Light)() {
        // TODO implement here
    }

    /**
     * 
     */
    public void execute() {
        // TODO implement here
    }

    /**
     * 
     */
    public void execute() {
        // TODO implement here
    }

}