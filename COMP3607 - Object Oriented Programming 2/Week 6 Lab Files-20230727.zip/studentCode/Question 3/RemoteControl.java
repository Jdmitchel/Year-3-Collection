
import java.util.*;

/**
 * 
 */
public class RemoteControl {

    /**
     * Default constructor
     */
    public RemoteControl() {
    }

    /**
     * 
     */
    private void Command;




    /**
     * @param Command
     */
    public void setCommand(void Command) {
        // TODO implement here
    }

    /**
     * 
     */
    public void pressButton() {
        // TODO implement here
    }

}