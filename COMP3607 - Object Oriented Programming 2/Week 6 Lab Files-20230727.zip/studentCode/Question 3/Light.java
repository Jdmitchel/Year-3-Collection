
import java.util.*;

/**
 * 
 */
public class Light {

    /**
     * Default constructor
     */
    public Light() {
    }

    /**
     * 
     */
    private boolean on;

    /**
     * @return
     */
    public boolean switchOn() {
        // TODO implement here
        return false;
    }

    /**
     * @return
     */
    public boolean switchOff() {
        // TODO implement here
        return false;
    }

}