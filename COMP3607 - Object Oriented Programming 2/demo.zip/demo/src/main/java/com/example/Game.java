package com.example;
// Design pattern used: Template
public abstract class Game {
    protected int score;
    public Game(){

    }
    //Template method
    public final void playGame(){
        initialise();
        startPlay();
        play();
        endPlay();

    }
    public int getScore(){
        return score;
    }
    //Concrete or hook (default implementation)
    public  void initialise(){
        System.out.println("Welcome to the Game");
    }
    public  void startPlay(){
        score =0;
    }
    public  void endPlay(){
        System.out.println("Thanks for playing! Your score is: " + getScore()+"\n");
    }

    //abstract methods for subclasses
    public abstract void play();
   


}
