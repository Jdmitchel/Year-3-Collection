package com.example;

public interface GameStrategy {
    public abstract int play();
}
