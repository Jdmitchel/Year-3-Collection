package com.example;

/**
 * Hello world!
 *
 */
public class App {
    public static void main( String[] args ){
        Game game1 = new GuessingGame();
        game1.playGame();
    }
}
