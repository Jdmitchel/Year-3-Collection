package com.example;

public class GuessingGame extends Game{
    private String[] animals; //strAr1=new String[] {"Ani", "Sam", "Joe"};
    private String question;
    private String answer;
    private GameStrategy strategy;

    public GuessingGame(){
        animals = new String[3];
        animals[0]= "Baracuda";
        animals[1]= "Orca" ;
        animals[2]="Pangolin" ;
        //strategy = new GuessingGameStrategy(animals);
        strategy = new GuessingGameStrategy2(animals);
        
    }


    public  void play(){
        int gameScore = strategy.play();
        this.score = gameScore;
    }

}
