package com.example;

public class GuessingGameStrategy2 implements GameStrategy{

    private String[] answers;

    public GuessingGameStrategy2(String[] answers){
        this.answers = answers;
    }

    public int play(){
        String answer;
        int score=0;

        for (int i = 0; i<answers.length; i++){
            int numTries=0; 
            boolean solved = false; 
            while (numTries < 5 && !solved){
                System.out.println("What animal am I thinking of?"); 
                java.util.Scanner screen = new java.util.Scanner(System.in);
                
                answer = screen.nextLine().trim();
                numTries++;
            
                if(answer.equals(answers[i])){
                    score++;
                    solved = true;
                    if(numTries >4)
                        System.out.println("Finally.......correct, yes...sigh");
                    else
                        System.out.println("Correct, yes");
                    
                }
                else{
                    if(numTries == 5)
                        System.out.println("Okay..we need to move on. You can't guess that");
                    else
                        System.out.println("Incorrect, no..try again!");
                }
            }
            
        }
        return score;
    }
}
