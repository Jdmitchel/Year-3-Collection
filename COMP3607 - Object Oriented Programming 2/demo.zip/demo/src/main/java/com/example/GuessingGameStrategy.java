package com.example;

public class GuessingGameStrategy implements GameStrategy{

    private String[] answers;

    public GuessingGameStrategy(String[] answers){
        this.answers = answers;
    }

    public int play(){
        String answer;
        int score=0;
        for (int i = 0; i<answers.length; i++){
            System.out.println("What animal am I thinking of?"); 
            java.util.Scanner screen = new java.util.Scanner(System.in);
            answer = screen.nextLine().trim();
            if(answer.equals(answers[i])){
                score++;
                System.out.println("Correct, yes");
            }
            else{
                System.out.println("Incorrect, no");
            }
        }
        return score;
    }
}
