package week10;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
//import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

public class LecturerTest{
    private Lecturer bob = new Lecturer("Bob", "Doe", "Assistant Lecturer"); //10

    /*@BeforeAll
    public void setUp() {
        bob 
    }*/
    @Test
    public void testGetFirstName() {
        System.out.println("getFirstName"); 
        String expResult = "Bob";
        String result = bob.getFirstName();
        assertEquals(expResult, result);
    }
    @Test
    public void testGetLastName() {
        System.out.println("getLastName"); 
        String expResult = "Doe";
        String result = bob.getLastName();
        assertEquals(expResult, result);
    }
    @Test
    public void testGetPosition() {
        System.out.println("getPosition"); 
        String expResult = "Assistant Lecturer";
        String result = bob.getPosition();
        assertEquals(expResult, result);
    }
    @Test
    public void testGetSalary() {
        System.out.println("getSalary"); 
        double expResult = 5000;
        double result = bob.getSalary();
        assertEquals(expResult, result, 0.0);
    }

    @Test
    public void testGetID() {
        assertEquals(10, bob.getID());
    }
    
    @Test
    public void testIDIncrement() {
        System.out.println("getID"); 
        Lecturer phil = new Lecturer ("Phillip", "Head", "Lecturer");//20
        Lecturer jane = new Lecturer ("Jane", "June", "Lecturer");//30
        int expResult = phil.getID(); //x
        int actualResult = jane.getID(); //x+10
        assertEquals(expResult+10, actualResult);
    }



}