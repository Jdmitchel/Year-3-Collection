  
  public class Item implements Snack {

    private String id;
    private String name;
    private double price;
  
    public Item(String ID, String name, double price) {
      this.id =ID;
      this.name = name;
      this.price = price;
    }
  
  
    @Override
    public String getID() {
     return this.id;
    }
  
  
    @Override
    public String getName() {
    return this.name;
    }
  
  
    @Override
    public double getPrice() {
    return this.price;
    }
  
  
    @Override
    public int getNumItems() {
     return 0;
    }
  
  
    @Override
    public String toString() {
      return "ID: " + this.id + "\t Name: " + this.name + "\t Price: $" + Double.toString(price);    }
  }


