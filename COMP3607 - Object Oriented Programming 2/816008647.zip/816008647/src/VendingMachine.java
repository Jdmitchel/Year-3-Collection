  import java.util.ArrayList;
  import java.util.List;
  
  public class VendingMachine{
      private List<Snack> snacks = new ArrayList<>();
      private List<Snack> combos = new ArrayList<>();
      private Order Order = new Order();
      private Payment Payment = new CashPayment(0);

       public VendingMachine(){
         snacks = new ArrayList<Snack>();
         combos = new ArrayList<Snack>();
         Order = new Order();
         Payment = new CashPayment(0);
       }
      public void addSnack(Snack snack) {
         this.snacks.add(snack);
         System.out.println(snack.toString());
      }

      public void addCombo(Snack snack){
         this.combos.add(snack);
         System.out.println(snack.toString());

      }

  
    
      public Snack findItem(String id) {
         if(id.length()==3){
            for (Snack snack : this.snacks) {
               if (snack.getID().equalsIgnoreCase(id) ) {
                  return snack;
               }
            }
          }
         else 
         if(id.length()==5){
         for (Snack snack : this.combos) {
            if (snack.getID().equalsIgnoreCase(id) ) {
                return snack;
            }
         }

      }
   
      
      return null;
   }
  
    
    public void insertPayment(Payment payment) {

     this.Order = new Order();
     this.Payment = payment;
    }
  
    
    public void orderSnack(String snackId) throws Exception {
      
      Snack snack = findItem(snackId);
      
      if (snack == null) {
         throw new Exception("Snack 404.");
      }
      
      this.Order.addSnack(snack);
    }
  
    public String FillOrder() throws Exception {
           
         if (this.Order == null) {
            throw new Exception("Payment 404");
         }
          
          this.Order.pay(this.Payment);
         
          String receipt = this.Order.getDetails();
         this.Order = null;
           this.Payment = null;
          return receipt;
         }
    
      
}

