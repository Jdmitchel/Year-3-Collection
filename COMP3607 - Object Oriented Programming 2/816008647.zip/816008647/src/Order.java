  import java.util.ArrayList;
  import java.util.List;
  
  public class Order{
   private List<Snack> snacks = new ArrayList<>();
   
   private Payment payment;

   public Order(){
      payment = new CashPayment(0);
   }
   public void addSnack(Snack snack) throws Exception {
         this.snacks.add(snack);
    }
  
    
   public double getTotal() {
      double total = 0.00;
      
      for (Snack snack : this.snacks) {
         total += snack.getPrice();
      }

     return total;
    }
  
    
    public void pay(Payment payment) throws Exception {

      this.payment = payment;
      
      if (!payment.validatePayment(this)) {
         throw new Exception("Invalid payment.");
      }
      
      
    }
  
    
    public String getDetails() {
    String details = "Order:\n";
      
    for (Snack snack : this.snacks) {
       details = details + snack.toString() + "\n";
      }
      
      details = details + "Total: $" + Double .toString(getTotal());
      
      if (this.payment != null) {
       details = details + "\n";
       details = details + this.payment.getDetails() + "\n";
        
        try {
        details = details + "Change: " + this.payment.getDetails();
       } catch (Exception e) {
         e.printStackTrace(System.out);
        } 
      } 
     return details;
    }
  }


