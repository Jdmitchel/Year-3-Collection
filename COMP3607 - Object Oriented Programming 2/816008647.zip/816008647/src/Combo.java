  import java.util.ArrayList;
  import java.util.List;
  
  
  public class Combo implements Snack {
    
    private List<Snack> snacks = new ArrayList<>();;
    
    private String id;
    private String name;
    
    public Combo(String name,String ID) {
        this.id = ID;
        this.name = name;
        this.snacks = new ArrayList<Snack>();
    }
  
    
    public void addSnack(Snack snack) {
        this.snacks.add(snack);
    }
  
  
    @Override
    public String getID() {
        return this.id;
    }
  
  
    @Override
    public String getName() {
        return this.name;
    }
  
  
    @Override
    public double getPrice() {
        double total = 0.00;
      
        for (Snack snack : this.snacks) {
            total += snack.getPrice();
        } 
         return total*.80;
    }
  
  
    @Override
    public int getNumItems() {
     return this.snacks.size();
    }

    @Override
    public String toString() {
        String details = "ID: " + this.id + "\t Name: " + this.name + "\nSnacks: ";
        for(Snack snack:this.snacks){
         details += snack.toString() +"\n"; 
        } 
        return details+= "Price: $"+ Double.toString(getPrice())+"\n\n";
    }
  }


 