  
public class CashPayment implements Payment{

    private double amountTendered;

    public CashPayment(double amountTendered) {

    this.amountTendered = amountTendered;
    }
  
  
    
    public boolean validatePayment(Order order) {
     return (this.amountTendered >= order.getTotal());
    }
  
  
    
    public String getChangeDue(Order order) throws Exception {
      double changeDue = 0;
     if (!validatePayment(order)) {
       throw new Exception("Invalid payment.");
      }
      changeDue = amountTendered -order.getTotal();
      
     return "$"+Double.toString(changeDue);
    }
  
  
    
    public String getDetails() {
     return "PAYMENT TYPE: Cash \n Ammount Tendered: $" + Double.toString(amountTendered);
    }
  }


