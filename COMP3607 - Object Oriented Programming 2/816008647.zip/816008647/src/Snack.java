public interface Snack {
  
  public String getID();
  
  public String getName();
  
  public double getPrice();
  
  public int getNumItems();
  
  public String toString();
}


