import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;
 
public class Cafeteria{

   public static void main(String[] args) throws Exception {
        VendingMachine vm = new VendingMachine();
        Snack snack = new Item("1", "1", 1);
        // Import Items
        try {
            BufferedReader br = new BufferedReader(new FileReader("C:/Users/jiles/demo/src/main/java/com/example/items.txt"));
            String data = br.readLine();
            
            
            while (data!=null) {
                String[] itemdata = data.split("\t");
  
                snack = new Item(itemdata[0], itemdata[1],Double.parseDouble(itemdata[2].replace("$", "").replace(",", "")));
                vm.addSnack(snack);
                data = br.readLine(); 
              }
              br.close();
            } 
            catch (FileNotFoundException e) {
              System.out.println("An error occurred.");
              e.printStackTrace();
        }
        
   
        // Import Combos
        try {
        BufferedReader br = new BufferedReader(new FileReader("C:/Users/jiles/demo/src/main/java/com/example/combos.txt"));
        String data = br.readLine();
        
          while (data!=null) {
            String[] itemdata = data.split("\t");

            //Create new Combo object
            Combo combo = new Combo(itemdata[1], itemdata[0]);
            itemdata = itemdata[2].split(",");
            //fill snack data
            for(String s : itemdata){
              if(s.length() == 3){
                  if(vm.findItem(s).getID().equals(s)){
                    combo.addSnack(vm.findItem(s));
                  }               
                else{                 
                    if(vm.findItem(s).getID().equals(s)){
                        combo.addSnack(vm.findItem(s));
                  }
                } 
                }
            }
            vm.addCombo(combo);
            data = br.readLine(); 
          }
          br.close();
        } catch (FileNotFoundException e) {
          System.out.println("An error occurred.");
          e.printStackTrace();
        }

        try {
            BufferedReader br = new BufferedReader(new FileReader("C:/Users/jiles/demo/src/main/java/com/example/orders.txt"));
            String data = br.readLine();
            Scanner scanner = new Scanner(System.in);
            
              while (data!=null) {
                  String[] itemdata = data.split("\t");
                  
  
                  String[] snacklist = itemdata[2].split(",");
                  //fill out items
                  for(String s:snacklist){
                       vm.orderSnack(s);
                  System.out.println("ping");
  
                  }  
  
                  // payment type
                  if (itemdata[1].equalsIgnoreCase("CASH")) {
                      System.out.println("Input Cash Amount: $");
                      vm.insertPayment(new CashPayment(scanner.nextDouble()));
                  }  
                  else{
                      if (itemdata[1].equalsIgnoreCase("CARD")) {
                          System.out.println("Input Card Expiry Date: ");
                          vm .insertPayment(new CardPayment(CardPayment.DATE_FORMAT.parse(scanner.next()))); 
                      } 
                      else {
                          throw new Exception("Payment type Error.");
                       } 
                  }
              //fill order 
               vm.FillOrder();
              data = br.readLine(); 
              }
              br.close();
              scanner.close();
            } catch (FileNotFoundException e) {
              System.out.println("An error occurred.");
              e.printStackTrace();
            }
            
        }
    

    

 }


