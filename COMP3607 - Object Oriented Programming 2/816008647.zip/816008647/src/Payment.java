public interface Payment {
  boolean validatePayment(Order paramOrder);
  
  String getChangeDue(Order paramOrder) throws Exception;
  
  String getDetails();
}


