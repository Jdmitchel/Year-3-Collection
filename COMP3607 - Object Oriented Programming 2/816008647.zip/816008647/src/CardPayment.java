  import java.text.DateFormat;
  import java.text.SimpleDateFormat;
  import java.util.Date;
  
  public class CardPayment
    implements Payment
  {
   public static final DateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
    
    private Date exp;
    
    public CardPayment(Date expiryDate) {
     this.exp = expiryDate;
    }
  
  
    
    public boolean validatePayment(Order order) {
     return (this.exp.compareTo(new Date()) >= 0);
    }
  
  
    
    public String getChangeDue(Order order) throws Exception {
    return "$0";
    }
  
  
    
    public String getDetails() {
     return "PAYMENT TYPE: Card \n Exp: " + DATE_FORMAT.format(this.exp);
    }
  }


