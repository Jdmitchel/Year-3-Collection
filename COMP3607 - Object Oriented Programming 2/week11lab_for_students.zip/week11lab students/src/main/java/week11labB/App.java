package week11labB;
// include appropriate imports

public final class App {
 
    public static void main(String[] args) {
        //Create a few activity objects and store in a collection

        //Declare Generic export/import objects
   
        // JSON export/import invocations
  
        
        //XML export/import invocations
    
     
    }
}

