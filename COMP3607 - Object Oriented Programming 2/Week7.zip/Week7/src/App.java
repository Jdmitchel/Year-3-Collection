public class App {
    public static void main(String[] args) throws Exception {
       
        Patient p = new Patient();
        p.hookUpMonitors();
    }
}
