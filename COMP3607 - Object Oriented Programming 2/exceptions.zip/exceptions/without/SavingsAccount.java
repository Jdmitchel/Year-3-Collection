public class SavingsAccount extends Account{
	
	public SavingsAccount(int number, double balance){
		super(number, balance);
	}
	
	public String toString(){
		String s = "Savings :"+super.toString();
		return s;
	}
}
	