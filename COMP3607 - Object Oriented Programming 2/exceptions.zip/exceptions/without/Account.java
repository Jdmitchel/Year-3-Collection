public class Account{
	private int number;
	private double balance;
	
	public Account(int num, double bal){
		number = num;
		balance = bal;
	}
	
	public void withdraw(double amount){
 		if(amount < balance){
			balance = balance-amount;
		}
	}
	
	
	public void deposit(double amount){
		balance = balance + amount;
	}
	
	public String toString(){
		return number + " " + balance;
	}
	
}