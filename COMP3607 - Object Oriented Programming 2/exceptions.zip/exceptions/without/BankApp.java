public class BankApp {
    public static void main(String[] args){
        Account a = new ChequingAccount (10, 50000.00);
        a.withdraw(49999.99);
        System.out.println(a.toString());
    }
          
}
