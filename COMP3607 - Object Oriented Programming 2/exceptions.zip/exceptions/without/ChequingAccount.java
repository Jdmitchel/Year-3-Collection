public class ChequingAccount extends Account{
	
	private int numTransactions;
	private double fees;
	
	public ChequingAccount(int number, double balance){
		super(number, balance);
	}
	
	public void calculateFees(){
		fees = numTransactions * 0.75;
	}
	
	public void withdraw(double amount){
		super.withdraw(amount);
		numTransactions++;
	}
	
	public String toString(){
		String s = "Chequing :"+super.toString();
		s= s + " "+ numTransactions +" " + fees;
		return s;
	}
	
}