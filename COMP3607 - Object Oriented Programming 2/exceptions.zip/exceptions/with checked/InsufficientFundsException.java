public class InsufficientFundsException extends Exception{
	
	public InsufficientFundsException(){
		super("Not enough funds to permit operation");
	}
	
	public InsufficientFundsException(String message){
		super(message);
	}
	
	
}