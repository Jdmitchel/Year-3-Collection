public class TooLargeWithdrawalException extends Exception{
	
	public TooLargeWithdrawalException(){
		super("Not enough funds to permit operation");
	}
	
	public TooLargeWithdrawalException(String message){
		super(message);
	}
	
	
}