public class BankApp{
	
	public static void main(String[] args){
		Account a = new ChequingAccount (10, 800.00);
		try{
 			a.withdraw(1000.00);
		}
		catch(InsufficientFundsException ife){
			System.out.println(ife.getMessage());
		}
		catch(TooLargeWithdrawalException tlwe){
			System.out.println(tlwe.getMessage());
		}
		System.out.println(a.toString());
	
	}
}