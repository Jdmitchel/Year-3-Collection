public class Account{
	private int number;
	private double balance;
	
	public Account(int num, double bal){
		number = num;
		balance = bal;
	}
	
	public void withdraw(double amount) throws InsufficientFundsException, 
											TooLargeWithdrawalException{
		
		if(amount > 10000){
			String message = "You cannot withdraw more than $10,000 in one transaction";
			throw new TooLargeWithdrawalException(message);
		}
		
		if(amount < balance){
			balance = balance-amount;
		}
		else{
			throw new InsufficientFundsException();
		}
	}
	
	
	public void deposit(double amount){
		balance = balance + amount;
	}
	
	public String toString(){
		return number + " " + balance;
	}
	
}