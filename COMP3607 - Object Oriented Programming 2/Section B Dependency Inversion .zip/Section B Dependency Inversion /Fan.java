public class Fan{


    public void turnOn()
    {
        System.out.println("Lamp turned on");
    }

    public void turnOff()
    {
        System.out.println("Lamp turned off");
    }

    
}