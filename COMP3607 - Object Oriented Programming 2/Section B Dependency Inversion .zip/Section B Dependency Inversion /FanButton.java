public class FanButton extends Button{
 
    private Fan fan;

    private boolean state;

    public FanButton(Equipment fan)
    {
       super(fan);
    }

    public void toggle()
    {
        state = !state;
        boolean buttonOn = state;
        if (buttonOn) {
            fan.turnOn();
        } else {
            fan.turnOff();
        }
    }
}