public class LampButton extends Button{

    public LampButton(Equipment lamp)
    {
       super(lamp);
    }

    
}