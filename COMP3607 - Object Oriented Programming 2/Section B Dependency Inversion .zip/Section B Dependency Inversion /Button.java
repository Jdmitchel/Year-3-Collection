public class Button 
{
    private Equipment device;
    private boolean state;

    public Button(Equipment device){
        this.device = device;
    }

    public void toggle()
    {
        state = !state;
        boolean buttonOn = state;
        if (buttonOn) {
            device.turnOn();
        } else {
            device.turnOff();
        }
    }

}
