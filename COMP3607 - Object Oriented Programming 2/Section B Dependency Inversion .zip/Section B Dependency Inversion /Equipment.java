public interface Equipment{
    public void turnOn();
    public void turnOff();
}