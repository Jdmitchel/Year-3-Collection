public class App{
    public static void main(String[] args){
        Lamp lamp = new Lamp();
        LampButton lb= new LampButton(lamp);
        lb.toggle();

    }

    
}