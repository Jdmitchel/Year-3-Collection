##########################################################################
"""
Add two client ints and return sum
             
"""

from socket import *

 
serverPort = 12009

# create UDP socket and bind to your specified port
serverSocket = socket(AF_INET, SOCK_DGRAM)
serverSocket.bind(("", serverPort))

print ("The Add two ints server is ready to receive ... ")

while 1:
    int1, clientAddress = serverSocket.recvfrom(2048)
    print ("Received from Client: ", int1.decode())
    int1=int(int1)

    int2, clientAddress = serverSocket.recvfrom(2048)
    print ("Received from Client: ", int2.decode())
    int2=int(int2)
	
    send_data=str(int1 + int2)
    message=send_data.encode('utf-8')

    serverSocket.sendto(message, clientAddress)
 
    print ("Sent back to Client: ", message.decode())
'''

'''
