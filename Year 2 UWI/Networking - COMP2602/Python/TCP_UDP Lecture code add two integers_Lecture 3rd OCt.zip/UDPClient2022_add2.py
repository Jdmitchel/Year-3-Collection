from socket import *

serverName = "localhost"

serverPort = 12009
clientSocket = socket(AF_INET, SOCK_DGRAM)

while 1:
 print("Input the value of a & b")
 a, b = map(int, input().split())
 print("The value of a & b are: ",a,b)

 send_data = str(a)
 message=send_data.encode('utf-8')
 clientSocket.sendto(message,(serverName, serverPort))
 print ("Sent ", a, " to server")

 send_data = str(b)
 message=send_data.encode('utf-8')
 clientSocket.sendto(message,(serverName, serverPort))
 print ("Sent ", b, " to server")
 result, serverAddress = clientSocket.recvfrom(2048)

 print ("Received back from Server: ", result.decode())

clientSocket.close()

'''
'''
