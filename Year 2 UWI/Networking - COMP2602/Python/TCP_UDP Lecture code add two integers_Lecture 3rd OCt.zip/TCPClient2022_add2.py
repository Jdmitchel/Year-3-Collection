"""  TCPClient.py """

from socket import *

serverName = "localhost"
serverPort=1211

clientSocket = socket(AF_INET, SOCK_STREAM)

clientSocket.connect((serverName,serverPort))
print(str(clientSocket))
while 1:
 print("Input the value of a & b")
 a, b = map(int, input().split())
 print("The value of a & b are: ",a,b)

 send_data = str(a)
 message=send_data.encode('utf-8')
 clientSocket.send(message)
 print ("Sent ", a, " to server")

 send_data = str(b)
 message=send_data.encode('utf-8')
 clientSocket.send(message)
 print ("Sent ", b, " to server")

 result = clientSocket.recv(2024)

 print ("Received back from Server: ", result.decode())

clientSocket.close()
