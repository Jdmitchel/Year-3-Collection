
from socket import *


serverPort = 1211


serverSocket = socket(AF_INET,SOCK_STREAM)
serverSocket.bind(("",serverPort))

serverSocket.listen(1)
print ("The Add 2 server running over TCP is ready to receive ... ")
connectionSocket, addr = serverSocket.accept()
#addr is client that is connecting and connectionSocket is auxilliary socket at server

while 1:

    int1 = connectionSocket.recv(1024)
    print ("Received from Client: ", int1.decode())

    int1=int(int1)

    int2 = connectionSocket.recv(1024)
    print ("Received from Client: ", int2.decode())
    int2=int(int2)
	
    send_data=str(int1 + int2)
    message=send_data.encode('utf-8')

    connectionSocket.send(message)

    print ("Sent back to Client: ", message.decode())


connectionSocket.close()
##########################################################################
"""

             
"""

