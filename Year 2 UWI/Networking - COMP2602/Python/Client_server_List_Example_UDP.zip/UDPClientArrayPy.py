from socket import *


serverName = "localhost"

serverPort = 12004

clientSocket = socket(AF_INET, SOCK_DGRAM)

tempList = []
print (tempList)

tempList.append("John")
tempList.append("Francis")
tempList.append("Amy")
tempList.append("Jada")
print (tempList)
count = 0
while count < len(tempList) :
   clientSocket.sendto(bytes(tempList[count],"utf-8"), (serverName, serverPort))
   print ("Sent " + tempList[count] + " to server.")
   result, serverAddress = clientSocket.recvfrom(2048)
   print ("Received back from Server: ", result.decode())
   count+=1
   
clientSocket.close()

'''
[]
['John', 'Francis', 'Amy', 'Jada']
Sent John to server.
Received back from Server:  JOHN
Sent Francis to server.
Received back from Server:  FRANCIS
Sent Amy to server.
Received back from Server:  AMY
Sent Jada to server.
Received back from Server:  JADA
'''
