from socket import *

serverPort = 12004


serverSocket = socket(AF_INET, SOCK_DGRAM)
serverSocket.bind(("", serverPort))


print ("The Make Upper Case Server running over UDP is ready to receive ... ")

while 1:
    
    message, clientAddress = serverSocket.recvfrom(2048)
    print ("Received from Client: ", message)
    modifiedMessage = message.upper()
	
    serverSocket.sendto(modifiedMessage, clientAddress)
    print ("Sent back to Client: ", modifiedMessage)

'''

'''
