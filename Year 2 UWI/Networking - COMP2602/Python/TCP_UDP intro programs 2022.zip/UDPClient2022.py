from socket import *

serverName = "127.0.0.1"

serverPort = 1212
clientSocket = socket(AF_INET, SOCK_DGRAM)

message = input("Input lowercase sentence: ")

clientSocket.sendto(bytes(message,"utf-8"), (serverName, serverPort))

print ("Sent to Make Upper Case Server running over UDP: ", message)

modifiedMessage, serverAddress = clientSocket.recvfrom(2048)

print ("Received back from Server: ", modifiedMessage.decode())

clientSocket.close()

'''
'''
