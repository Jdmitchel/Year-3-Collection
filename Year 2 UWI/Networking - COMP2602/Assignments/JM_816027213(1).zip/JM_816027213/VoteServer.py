from socket import *
#Jardel Mitchell - 816027213

port = 12009

server = socket(AF_INET, SOCK_STREAM)
server.bind(('localhost', port))
server.listen(1)

jane = 0
john = 0
count = 0
name = ''
name2 = ''

print("~~~~~~~ Election candidates ~~~~~~")

# accepts a connection from a client
connection, address = server.accept()
# receives data from the client
""" data = connection.recv(1024)
data = data.str(data,'utf-8') """
while True:
    for i in range(10):
        data = connection.recv(1024)
        data = str(data, 'utf-8')
        if data.strip() == "JaneD":
            jane+=1
            name = data
            #print(name + "\t" +str(jane))
            connection.send(bytes("vote successful\n", 'utf-8'))
        if data.strip() == "JohnD":
            john+=1
            name2 = data
            #print(name2 + "\t" +str(john))
            connection.send(bytes("vote successful\n", 'utf-8'))
        print(name + "\t"+ str(jane) +"\t" + name2 + " \t " + str(john))

    print("_____________________________________")
    print(name +" got " + str(jane) + " votes")
    print(name2 +" got " + str(john) + " votes")
    print("_____________________________________\n")

    if jane > john:
        print("_________________________________________________________________________")
        print(name + " is the winner" + " by " + str(jane - john) + " votes")
        print(name + " got " + str(jane) + " votes and " + name2 + " got " + str(john) + " votes, so " + name + " is the winner.")
        connection.send(bytes(name + " got " + str(jane) + " votes and " + name2 + " got " + str(john) + " votes, so " + name + " is the winner.", 'utf-8'))
        print("_________________________________________________________________________")


    if john > jane:
        print("_________________________________________________________________________")
        print(name2 + " is the winner" + " by " + str(john - jane) + " votes")
        print(name2 + " got " + str(john) + " votes and " + name + " got " + str(jane) + " votes, so " + name2 + " is the winner.")
        connection.send(bytes(name + " got " + str(jane) + " votes and " + name2 + " got " + str(john) + " votes, so " + name2 + " is the winner.", 'utf-8'))
        print("_________________________________________________________________________")
    
    if jane == john:
        print("_________________________________________________________________________")
        print("It's a tie!")
        print(name + " got " + str(jane) + " votes and " + name2 + " got " + str(john) + " votes, so it's a tie.")
        connection.send(bytes(name + " got " + str(jane) + " votes and " + name2 + " got " + str(john) + " votes, so it's a tie.", 'utf-8'))
        print("_________________________________________________________________________")

#send results to client
connection.close()


