from socket import *
#Jardel Mitchell - 816027213

port = 12009

client = socket(AF_INET, SOCK_STREAM)
client.connect(('localhost', port))

# opens the file and reads the votes
file = open('votes.txt', 'r')
#file = file.readlines()

while True:
    # read the votes and sends them to the server
    for line in file:
        line = line.strip()
        client.send(bytes(line, 'utf-8'))
    # print('Sent to Server: ', line)
        data = client.recv(1024)
        data = data.decode('utf-8')
        print(data)
    print("End of voting")

    # receive data from the server
    data = client.recv(1024)
    data = data.decode('utf-8')
    print("_________________________________________________________________________")
    print('\t\t\tThe Votes are in!')
    print("_________________________________________________________________________")
    print(data)
    print("_________________________________________________________________________")

# closes the connection
client.close()
