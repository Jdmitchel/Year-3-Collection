from socket import *
#Jardel Mitchell 816027213

address = ("127.0.0.1", 12009)

client = socket(AF_INET, SOCK_DGRAM)

equationsfile = open("input.txt", "r")
equations = equationsfile.readlines()

file1 = open("input.txt", "r")
#file2 = open("output.txt", "w")
lines = file1.readlines()

#strip the new line character from the end of each line and send it to the server
for line in lines:
    if line == "***":
        client.sendto(bytes(line, "utf-8"), address)
        break
    line = line.strip()
    client.sendto(bytes(line, "utf-8"), (address))
   # print(line)

    result, address = client.recvfrom(2048)
    result = result.decode("utf-8")
    print(line + " = " + result)




client.close()


