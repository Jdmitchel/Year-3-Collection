from ast import operator
from socket import *
#Jardel Mitchell 816027213

portNumber = 12009

server = socket(AF_INET, SOCK_DGRAM)
server.bind(("", portNumber))
outputfile = open("output.txt", "w")
outputfile.write("Infix Expression \t\t\t Value \n")
print("Assignemnt 1: UDP Server Calculator")

while 1:
    message, address = server.recvfrom(2048)
    print("Infix Expression \t\t\t Value")
    print("--------------------------------------------------")

    num=message.decode("utf-8")
    if num == "***":
        print("------------------------------")
        server.close()
        exit()

    value = 0
    num1 = 0
    num2 = 0
    answer = 0

    for x in range(0, len(num)):
        if ((num[x]!="+")and(num[x]!="-")and(num[x]!="/")and(num[x]!="*")):
            if value ==0:
                num1 = num[x] 
                value = 1 
            if value == 1:
                num2=num[x]
        else:
            operator=num[x]

    # calculate the answer
    if str(operator)=="+":
        answer=int(num1) + int(num2)
        answer=str(answer)
        answer=bytes(answer,"utf-8")
        print(num,"     ",answer)
        server.sendto(answer,(address))
        outputfile.write(num + "\t\t\t\t\t" + answer.decode("utf-8") + "\n")
        

    elif str(operator)=="-":
        answer = int(num1) - int(num2)
        answer = str(answer)
        answer = bytes(answer,"utf-8")
        print(num,"     ",answer)

        server.sendto(answer,(address))
        outputfile.write(num + "\t\t\t\t\t" + answer.decode("utf-8") + "\n")
        
    elif str(operator)=='*':
        answer = int(num1) * int(num2)
        answer = str(answer)
        answer = bytes(answer,"utf-8")
        print(num,"     ",answer)

        server.sendto(answer,(address))
        outputfile.write(num + "\t\t\t\t\t" + answer.decode("utf-8") + "\n")

    elif str(operator)=="/":
        answer = int(num1) / int(num2)
        answer = str(answer)
        answer = bytes(answer,"utf-8")
        print(num,"     ",answer)

        server.sendto(answer,(address))
        outputfile.write(num + "\t\t\t\t\t" + answer.decode("utf-8") + "\n")
       
    elif num == " ":
        print("\n")
        outputfile.write("\n")

    


server.close()