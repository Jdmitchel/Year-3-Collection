import javax.swing.*;

public class GameApplication
{
	public static void main (String[] args) {

		JFrame gameWindow = new GameWindow();
	}

}
