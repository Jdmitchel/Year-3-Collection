import javax.swing.*;

public class GameApplication
{
	public static void main (String[] args) {

      		JFrame frame = new GameWindow();
	}

}
