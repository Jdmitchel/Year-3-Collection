If you want the background music, you need to copy Background.wav
to this folder. Background.wav is available in the sounds folder
of previous examples.